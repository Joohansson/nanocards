self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "00e67eef590b2abb651ae9d73aa240cc",
    "url": "./index.html"
  },
  {
    "revision": "12d124f0f8ce8a7bde6a",
    "url": "./static/css/2.510409cd.chunk.css"
  },
  {
    "revision": "67b80f8caffe57d5df5f",
    "url": "./static/css/main.8ca1f2c6.chunk.css"
  },
  {
    "revision": "12d124f0f8ce8a7bde6a",
    "url": "./static/js/2.f57a8a36.chunk.js"
  },
  {
    "revision": "67b80f8caffe57d5df5f",
    "url": "./static/js/main.97ceec73.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "0453182f82c7966166f04704db35a3a7",
    "url": "./static/media/NotoSans-Bold.0453182f.woff"
  },
  {
    "revision": "20d4b4485cd3ebb8588306b63ac232b6",
    "url": "./static/media/NotoSans-Bold.20d4b448.eot"
  },
  {
    "revision": "5599230ec1b9d96256b16c9e40e4eccb",
    "url": "./static/media/NotoSans-Bold.5599230e.ttf"
  },
  {
    "revision": "a3b0a82afc4582358f83f87d2c150964",
    "url": "./static/media/NotoSans-Bold.a3b0a82a.woff2"
  },
  {
    "revision": "06d100cbc80aa1ed3a7643005794fda7",
    "url": "./static/media/NotoSans-Regular.06d100cb.eot"
  },
  {
    "revision": "aa283550181a649994822d16dd2d8e91",
    "url": "./static/media/NotoSans-Regular.aa283550.woff2"
  },
  {
    "revision": "edbefd4189c1916795792fcfa9c08e11",
    "url": "./static/media/NotoSans-Regular.edbefd41.ttf"
  },
  {
    "revision": "fbe46f26a3381739983bef1da5c94fbd",
    "url": "./static/media/NotoSans-Regular.fbe46f26.woff"
  },
  {
    "revision": "0f8590fdc3583de81a77a381dcc30c67",
    "url": "./static/media/Nunito-Light.0f8590fd.woff"
  },
  {
    "revision": "26b9fa9cc012171ee3cc7d6747a94d83",
    "url": "./static/media/Nunito-Light.26b9fa9c.woff2"
  },
  {
    "revision": "60cd5285d05fdd00bc81389a2bb23191",
    "url": "./static/media/Nunito-Light.60cd5285.ttf"
  },
  {
    "revision": "64365c70520820fc3bae6d8d13a02c1b",
    "url": "./static/media/Nunito-Light.64365c70.eot"
  },
  {
    "revision": "686ca529206c96492e56d748eb01ff84",
    "url": "./static/media/disconnected_b.686ca529.png"
  },
  {
    "revision": "4fb3b38edf239de14826154fd109b105",
    "url": "./static/media/disconnected_w.4fb3b38e.png"
  },
  {
    "revision": "b97f0e19669824b471f69e6064dcb10c",
    "url": "./static/media/donation.b97f0e19.png"
  },
  {
    "revision": "d6eccfc62261626ec365c5e7f0fd558d",
    "url": "./static/media/double_b.d6eccfc6.png"
  },
  {
    "revision": "1dddb5c9ebd958b33d4ca864964c9ade",
    "url": "./static/media/double_w.1dddb5c9.png"
  },
  {
    "revision": "e4734a77a42ac2fc25f825185c36c8bc",
    "url": "./static/media/firewall_b.e4734a77.png"
  },
  {
    "revision": "df70a0fa93c7850b1ba4a78ce39dd34b",
    "url": "./static/media/firewall_w.df70a0fa.png"
  },
  {
    "revision": "0990ec8850f93f36e03761fdc50f4523",
    "url": "./static/media/hacker_b.0990ec88.png"
  },
  {
    "revision": "98f530104a8b62f7cf09234b4a7c4492",
    "url": "./static/media/hacker_w.98f53010.png"
  },
  {
    "revision": "e37787db8d927c5e2852a51ea0a09617",
    "url": "./static/media/logo.e37787db.png"
  },
  {
    "revision": "0ae84ba6d90b8dc8067ce7c470355196",
    "url": "./static/media/modal-bg.0ae84ba6.png"
  },
  {
    "revision": "0f9c27e4c94fbd97b1d7e2e02c89d90e",
    "url": "./static/media/pay_b.0f9c27e4.png"
  },
  {
    "revision": "6d27e33199501e458cbecc979b4a9c34",
    "url": "./static/media/pay_data_b.6d27e331.png"
  },
  {
    "revision": "212debeb6dc23e5776c90679d09fe421",
    "url": "./static/media/pay_data_w.212debeb.png"
  },
  {
    "revision": "72ca9647f71dcfeeacf3dfd2b5da6667",
    "url": "./static/media/pay_w.72ca9647.png"
  },
  {
    "revision": "5e983e3069790433830414d42cbb5df5",
    "url": "./static/media/payout_b.5e983e30.png"
  },
  {
    "revision": "cae6ba247d0b3c2e485da6fc17e323ef",
    "url": "./static/media/payout_w.cae6ba24.png"
  }
]);